#!/usr/bin/env bash
# Instala lo necesario para el laboratorio de la Semana 7 (Debian 13 "trixie", sin entorno gráfico).
# Uso: bash setup_debian.sh      (pide sudo para apt)
set -euo pipefail
PAQ=(nmap tcpdump iproute2 iputils-ping nftables netcat-openbsd openssl python3 curl ca-certificates unzip)
echo "[*] Actualizando índices e instalando: ${PAQ[*]}"
sudo apt-get update -y
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "${PAQ[@]}"
# ndiff (comparar escaneos) viene en un paquete aparte en Debian; es opcional: el kit trae su propio comparador.
sudo apt-get install -y ndiff 2>/dev/null || echo "[i] ndiff no disponible: se usará reporte/comparar_escaneos.py"
echo; echo "[*] Verificación:"
for h in nmap tcpdump ip ping nft nc openssl python3 curl; do
  if command -v "$h" >/dev/null 2>&1; then printf "  [OK]    %s\n" "$h"; else printf "  [FALTA] %s\n" "$h"; fi
done
nmap --version | head -1
if ip netns add _probe 2>/dev/null; then ip netns del _probe; echo "  [OK]    espacios de red (ip netns)"; else sudo ip netns add _probe && sudo ip netns del _probe && echo "  [OK]    espacios de red (con sudo)"; fi
echo; echo "Listo. Siguiente paso: sudo bash red/lab_nmap.sh crear && sudo bash red/servicios.sh iniciar"
