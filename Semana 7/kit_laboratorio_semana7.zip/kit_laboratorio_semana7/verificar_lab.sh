#!/usr/bin/env bash
# Prueba de humo del laboratorio de Nmap. Úsala ANTES de la clase (docente) o si algo no responde (participante).
# Uso: sudo bash verificar_lab.sh      Crea el laboratorio, ejecuta las comprobaciones y lo deja armado.
set -uo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Ejecutá con sudo."; exit 1; }
cd "$(dirname "$0")"
unset HTTPS_PROXY https_proxy HTTP_PROXY http_proxy ALL_PROXY all_proxy
OK=0; MAL=0
# chk "descripción" 'patrón' comando...   -> pasa si la SALIDA del comando contiene el patrón
chk() { local d="$1" pat="$2"; shift 2; local out; out="$("$@" 2>&1)"; if [[ "$out" == *"$pat"* ]]; then echo "  [OK]    $d"; OK=$((OK+1)); else echo "  [FALLA] $d  (no apareció: $pat)"; MAL=$((MAL+1)); fi; }
nochk() { local d="$1" pat="$2"; shift 2; local out; out="$("$@" 2>&1)"; if [[ "$out" != *"$pat"* ]]; then echo "  [OK]    $d"; OK=$((OK+1)); else echo "  [FALLA] $d  (apareció: $pat)"; MAL=$((MAL+1)); fi; }
A=(ip netns exec auditor)
T="$(mktemp -d)"

bash red/lab_nmap.sh crear >/dev/null 2>&1; bash red/servicios.sh iniciar >/dev/null 2>&1
chk   "Descubrimiento LAN: 5 equipos activos (ARP)"          "(5 hosts up)"              "${A[@]}" nmap -sn 10.20.0.0/24
chk   "El DNS inverso muestra nombres (web.tiendanova.lab)"  "web.tiendanova.lab"        "${A[@]}" nmap -sn 10.20.0.20
chk   "Bastión: -sn NO lo ve (descarta ping y sondeos 80/443)" "(1 host up)"               "${A[@]}" nmap -sn 10.30.0.0/24
chk   "Bastión: -Pn lo asume activo y lo escanea"            "8443/tcp open"             "${A[@]}" nmap -Pn -p 22,80,8080,8443 10.30.0.20
chk   "Bastión: puerto 80 filtrado (sin respuesta)"          "80/tcp   filtered"         "${A[@]}" nmap -Pn -p 22,80,8080,8443 10.30.0.20
chk   "Bastión: puerto 8080 cerrado (RST)"                   "8080/tcp closed"           "${A[@]}" nmap -Pn -p 22,80,8080,8443 10.30.0.20
chk   "Escaneo por defecto de web: 4 puertos abiertos"       "3306/tcp open  mysql"      "${A[@]}" nmap 10.20.0.20
chk   "-sV detecta Apache 2.4.49"                            "Apache httpd 2.4.49"       "${A[@]}" nmap -sV -p 80 10.20.0.20
chk   "-sV detecta vsftpd 2.3.4 en la PC"                    "vsftpd 2.3.4"              "${A[@]}" nmap -sV -p 21 10.20.0.30
chk   "-sV detecta Escritorio Remoto (3389) en la PC"        "Microsoft Terminal Services" "${A[@]}" nmap -sV -p 3389 10.20.0.30
chk   "-sC muestra el título web y el certificado"           "ssl-cert"                  "${A[@]}" nmap -sC -p 443 10.20.0.20
chk   "-O responde (resultado puede variar según la versión de Nmap)" "OS"                "${A[@]}" nmap -O --osscan-guess 10.20.0.20
chk   "UDP: el DNS del gw (53/udp) está abierto"             "53/udp open"            "${A[@]}" nmap -sU -p 53 10.20.0.1

# captura: un escaneo -sS envía SYN y responde RST (nunca completa el saludo)
"${A[@]}" tcpdump -i eth0 -nn -U -w "$T/s.pcap" "host 10.20.0.20 and tcp" >/dev/null 2>&1 & TP=$!; sleep 1
"${A[@]}" nmap -sS -n -p 22 10.20.0.20 >/dev/null 2>&1; sleep 1; kill $TP 2>/dev/null; wait $TP 2>/dev/null
chk   "Captura -sS: SYN, SYN/ACK y RST del escáner"          "Flags [R]"                 tcpdump -nn -r "$T/s.pcap"

# reporte y comparación
"${A[@]}" nmap -sV -oX "$T/a.xml" -p 22,80 10.20.0.20 >/dev/null 2>&1
chk   "nmap_a_markdown genera el reporte"                    "| 80/tcp | open | http |" python3 reporte/nmap_a_markdown.py "$T/a.xml"
ip netns exec web python3 -m http.server 8000 >/dev/null 2>&1 & HP=$!; sleep 1
"${A[@]}" nmap -sV -oX "$T/b.xml" -p 22,80,8000 10.20.0.20 >/dev/null 2>&1
chk   "comparar_escaneos detecta el puerto nuevo 8000"       "puerto NUEVO abierto 8000/tcp" python3 reporte/comparar_escaneos.py "$T/a.xml" "$T/b.xml"
kill $HP 2>/dev/null; wait $HP 2>/dev/null
rm -rf "$T"
echo; echo "Resultado: $OK correctas, $MAL con falla."
[ "$MAL" -eq 0 ]
