#!/usr/bin/env python3
"""Servicios FICTICIOS para el laboratorio de Nmap (Semana 7).

Cada equipo del laboratorio ejecuta un "perfil": un conjunto de puertos con un comportamiento simulado.
Los banners (texto de versión) son simples cadenas configuradas aquí: NO hay software real ni vulnerable detrás.
Sirven para que Nmap tenga algo que detectar con -sV, -sC y -O.

Uso (dentro del espacio de red de cada equipo):
    sudo ip netns exec web python3 servicios_lab.py web
Perfiles: web, pc, imp, bastion, gw (DNS inverso)
"""
import http.server
import os
import socket
import socketserver
import ssl
import struct
import sys
import threading
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
CERT = os.path.join(AQUI, "pki", "servidor.crt")
KEY = os.path.join(AQUI, "pki", "servidor.key")


# ---------------------------------------------------------------- HTTP / HTTPS
def crear_http(server_header, titulo, cuerpo_extra=""):
    class H(http.server.BaseHTTPRequestHandler):
        def version_string(self):            # lo que el cliente ve en la cabecera "Server:"
            return server_header

        def sys_version(self):
            return ""

        def do_GET(self):
            ruta = self.path.split("?")[0]
            if ruta in ("/", "/index.html"):
                cuerpo, cod = f"<html><head><title>{titulo}</title></head><body><h1>{titulo}</h1>{cuerpo_extra}</body></html>", 200
            elif ruta.startswith("/admin"):
                cuerpo, cod = "<html><head><title>Panel de administracion</title></head><body>Acceso restringido</body></html>", 401
            else:
                cuerpo, cod = "<html><head><title>No encontrado</title></head><body>404</body></html>", 404
            datos = cuerpo.encode()
            self.send_response(cod)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(datos)))
            self.end_headers()
            self.wfile.write(datos)

        do_HEAD = do_GET

        def log_message(self, *a):
            pass

    return H


class ServidorHTTP(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def servir_http(puerto, handler, tls=False):
    srv = ServidorHTTP(("0.0.0.0", puerto), handler)
    if tls:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(CERT, KEY)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    threading.Thread(target=srv.serve_forever, daemon=True).start()


# ---------------------------------------------------------------- servicios TCP "crudos"
def tcp_servidor(puerto, atender):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", puerto))
    s.listen(64)

    def bucle():
        while True:
            c, _ = s.accept()
            threading.Thread(target=_seguro, args=(atender, c), daemon=True).start()

    threading.Thread(target=bucle, daemon=True).start()


def _seguro(atender, c):
    try:
        c.settimeout(20)
        atender(c)
    except Exception:
        pass
    finally:
        try:
            c.close()
        except Exception:
            pass


def banner(texto):
    def f(c):
        c.sendall(texto)
        try:
            c.recv(1024)
        except Exception:
            pass
    return f


def silencioso(c):            # acepta, no saluda, y corta al recibir el primer dato (servicio que no entiende a Nmap)
    try:
        c.settimeout(15)
        c.recv(1024)
    except Exception:
        pass


def rdp(c):                   # responde a la sonda RDP de Nmap con una "Connection Confirm" X.224 (como Escritorio Remoto)
    try:
        c.settimeout(15)
        datos = c.recv(1024)
        if datos[:2] == b"\x03\x00":
            c.sendall(b"\x03\x00\x00\x13\x0e\xd0\x00\x00\x124\x00\x02\x1f\x08\x00\x02\x00\x00\x00")
            time.sleep(1)
    except Exception:
        pass


def cerrar_ya(c):             # acepta y corta: Nmap lo reporta como "tcpwrapped"
    return


def ftp(c):
    c.sendall(b"220 (vsFTPd 2.3.4)\r\n")
    f = c.makefile("rb")
    for linea in f:
        cmd = linea.strip().upper().split(b" ")[0]
        if cmd == b"USER":
            c.sendall(b"331 Please specify the password.\r\n")
        elif cmd == b"PASS":
            c.sendall(b"530 Login incorrect.\r\n")
        elif cmd == b"QUIT":
            c.sendall(b"221 Goodbye.\r\n")
            return
        else:
            c.sendall(b"500 Unknown command.\r\n")


def mysql(c):
    version = b"5.5.62-0ubuntu0.14.04.1"
    salt1, salt2 = b"abcdefgh", b"ijklmnopqrst"
    cuerpo = (b"\x0a" + version + b"\x00" + struct.pack("<I", 7) + salt1 + b"\x00"
              + struct.pack("<H", 0xF7FF) + b"\x21" + struct.pack("<H", 2) + struct.pack("<H", 0x000F)
              + b"\x15" + b"\x00" * 10 + salt2 + b"\x00" + b"mysql_native_password\x00")
    c.sendall(struct.pack("<I", len(cuerpo))[:3] + b"\x00" + cuerpo)
    try:
        c.recv(1024)
    except Exception:
        pass


def telnet(c):
    c.sendall(b"\xff\xfd\x18\xff\xfd\x20\xff\xfd\x23\xff\xfd\x27")
    try:
        c.recv(1024)
    except Exception:
        pass


def ssh(version):
    return banner(f"SSH-2.0-{version}\r\n".encode())


# ---------------------------------------------------------------- perfiles
def perfil_web():
    h = crear_http("Apache/2.4.49 (Unix)", "TiendaNova - Tienda en linea")
    servir_http(80, h)
    servir_http(443, h, tls=True)
    tcp_servidor(22, ssh("OpenSSH_8.2p1 Ubuntu-4ubuntu0.5"))
    tcp_servidor(3306, mysql)


def perfil_pc():
    tcp_servidor(21, ftp)
    tcp_servidor(23, telnet)
    tcp_servidor(139, cerrar_ya)
    tcp_servidor(445, silencioso)
    tcp_servidor(3389, rdp)


def perfil_imp():
    servir_http(80, crear_http("Embedded HTTP Server 1.0", "Impresora Oficina - Panel de estado"))
    servir_http(631, crear_http("CUPS/2.4 IPP/2.1", "CUPS 2.4"))
    tcp_servidor(9100, silencioso)


def perfil_bastion():
    servir_http(8443, crear_http("nginx/1.24.0", "Portal de administracion TiendaNova"), tls=True)
    tcp_servidor(22, ssh("OpenSSH_9.2p1 Debian-2+deb12u3"))


# ---------------------------------------------------------------- DNS mínimo (solo consultas inversas PTR)
NOMBRES = {
    "10.20.0.1": "gw.tiendanova.lab", "10.20.0.10": "auditor.tiendanova.lab",
    "10.20.0.20": "web.tiendanova.lab", "10.20.0.30": "pc-oficina.tiendanova.lab",
    "10.30.0.1": "gw-dmz.tiendanova.lab", "10.30.0.20": "bastion.tiendanova.lab",
}   # la impresora (10.20.0.40) NO tiene nombre: nadie la registró


def perfil_gw():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("0.0.0.0", 53))

    def bucle():
        while True:
            datos, cli = s.recvfrom(512)
            try:
                s.sendto(responder_dns(datos), cli)
            except Exception:
                pass

    threading.Thread(target=bucle, daemon=True).start()


def responder_dns(q):
    ident = q[:2]
    i = 12
    partes = []
    while q[i] != 0:
        partes.append(q[i + 1:i + 1 + q[i]].decode())
        i += q[i] + 1
    fin = i + 1 + 4
    pregunta = q[12:fin]
    qtype = struct.unpack(">H", q[i + 1:i + 3])[0]
    nombre = ".".join(partes)
    ip = None
    if nombre.endswith(".in-addr.arpa"):
        ip = ".".join(reversed(nombre[:-len(".in-addr.arpa")].split(".")))
    if qtype == 12 and ip in NOMBRES:
        rd = b"".join(bytes([len(x)]) + x.encode() for x in NOMBRES[ip].split(".")) + b"\x00"
        resp = (ident + b"\x81\x80\x00\x01\x00\x01\x00\x00\x00\x00" + pregunta
                + b"\xc0\x0c\x00\x0c\x00\x01" + struct.pack(">IH", 60, len(rd)) + rd)
    else:   # NXDOMAIN
        resp = ident + b"\x81\x83\x00\x01\x00\x00\x00\x00\x00\x00" + pregunta
    return resp


PERFILES = {"web": perfil_web, "pc": perfil_pc, "imp": perfil_imp, "bastion": perfil_bastion, "gw": perfil_gw}

if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in PERFILES:
        sys.exit("Uso: servicios_lab.py " + "|".join(PERFILES))
    PERFILES[sys.argv[1]]()
    while True:
        time.sleep(3600)
