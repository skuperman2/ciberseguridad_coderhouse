#!/usr/bin/env bash
# Arranca o detiene los servicios ficticios en cada equipo del laboratorio.
# Uso: sudo bash servicios.sh iniciar|detener
set -uo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Ejecutá con sudo."; exit 1; }
DIR="$(cd "$(dirname "$0")" && pwd)"
PIDS="$DIR/.pids"
PKI="$DIR/pki"

detener() {
  if [ -f "$PIDS" ]; then
    while read -r p; do kill "$p" 2>/dev/null || true; done <"$PIDS"
    rm -f "$PIDS"
  fi
  [ "${1:-}" = "quiet" ] || echo "[OK] Servicios detenidos."
}

iniciar() {
  detener quiet
  ip netns list | grep -q '^web\b' || { echo "Primero: sudo bash $DIR/lab_nmap.sh crear"; exit 1; }
  if [ ! -f "$PKI/servidor.crt" ]; then
    mkdir -p "$PKI"
    openssl req -x509 -newkey rsa:2048 -nodes -keyout "$PKI/servidor.key" -out "$PKI/servidor.crt" -days 365 \
      -subj "/O=TiendaNova Lab/CN=tienda-web.lab" -addext "subjectAltName=DNS:tienda-web.lab" >/dev/null 2>&1
  fi
  : >"$PIDS"
  for par in web:web pc:pc imp:imp bastion:bastion gw:gw; do
    ns="${par%%:*}"; perfil="${par##*:}"
    ip netns exec "$ns" python3 "$DIR/servicios_lab.py" "$perfil" >/dev/null 2>&1 &
    echo $! >>"$PIDS"
  done
  sleep 2
  echo "[OK] Servicios ficticios en marcha (web, pc, imp, bastion y DNS en gw)."
}

case "${1:-}" in iniciar) iniciar ;; detener) detener "${2:-}" ;; *) echo "Uso: sudo bash $0 iniciar|detener"; exit 1 ;; esac
