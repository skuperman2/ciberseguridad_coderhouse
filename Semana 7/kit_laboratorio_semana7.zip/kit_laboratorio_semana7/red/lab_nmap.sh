#!/usr/bin/env bash
# Crea (o borra) la red virtual del laboratorio de Nmap, todo dentro de esta VM mediante espacios de red.
#
#   Segmento LAN  10.20.0.0/24  (un "switch" virtual: sw)
#     auditor 10.20.0.10  <- la computadora del auditor (desde acá se lanza Nmap)
#     web     10.20.0.20  <- servidor de la tienda
#     pc      10.20.0.30  <- PC de oficina
#     imp     10.20.0.40  <- impresora "olvidada"
#     gw      10.20.0.1 | 10.30.0.1  <- router/firewall entre LAN y DMZ
#   Segmento DMZ  10.30.0.0/24  (detrás de gw)
#     bastion 10.30.0.20  <- servidor protegido por firewall: no responde ping ni a los sondeos 80/443,
#                            deja pasar solo SSH (22) y un portal en 8443; el 8080 está cerrado
#
# Uso: sudo bash lab_nmap.sh crear|borrar|estado
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Ejecutá con sudo."; exit 1; }
DIR="$(cd "$(dirname "$0")" && pwd)"
NS=(sw auditor web pc imp gw bastion)

crear() {
  borrar quiet
  for n in "${NS[@]}"; do ip netns add "$n"; ip -n "$n" link set lo up; done
  ip -n sw link add br0 type bridge && ip -n sw link set br0 up
  # (host, última parte de la IP, MAC fija para que los resultados sean reproducibles)
  for par in auditor:10:10 web:20:20 pc:30:30 imp:40:40 gw:1:01; do
    IFS=: read -r h ip mac <<<"$par"
    ip link add "p$h" type veth peer name "q$h"
    ip link set "p$h" netns sw; ip link set "q$h" netns "$h"
    ip -n sw link set "p$h" master br0; ip -n sw link set "p$h" up
    ip -n "$h" link set "q$h" name eth0
    ip -n "$h" link set eth0 address "02:00:00:00:00:$mac"
    ip -n "$h" addr add "10.20.0.$ip/24" dev eth0; ip -n "$h" link set eth0 up
  done
  # DMZ: gw <-> bastion
  ip link add gwd type veth peer name bd
  ip link set gwd netns gw; ip link set bd netns bastion
  ip -n gw link set gwd name eth1; ip -n bastion link set bd name eth0
  ip -n gw link set eth1 address 02:00:00:00:00:02; ip -n bastion link set eth0 address 02:00:00:00:00:50
  ip -n gw addr add 10.30.0.1/24 dev eth1; ip -n gw link set eth1 up
  ip -n bastion addr add 10.30.0.20/24 dev eth0; ip -n bastion link set eth0 up
  # El auditor usa el DNS de gw (nombres inversos: Nmap los muestra en el informe)
  mkdir -p /etc/netns/auditor && echo 'nameserver 10.20.0.1' >/etc/netns/auditor/resolv.conf
  # Rutas: todos salen por gw; gw reenvía entre LAN y DMZ
  for h in auditor web pc imp; do ip -n "$h" route add default via 10.20.0.1; done
  ip -n bastion route add default via 10.30.0.1
  ip netns exec gw sysctl -qw net.ipv4.ip_forward=1
  # Firewall del bastión: política "drop" (todo lo no permitido se descarta en silencio) salvo 22 y 8443;
  # el 8080 se rechaza activamente (RST) para que Nmap lo vea CERRADO; el ping (ICMP echo) se descarta.
  ip netns exec bastion nft -f - <<'NFT'
table inet fw {
  chain input {
    type filter hook input priority 0; policy drop;
    iif "lo" accept
    ct state established,related accept
    tcp dport { 22, 8443 } accept
    tcp dport 8080 reject with tcp reset
  }
}
NFT
  echo "[OK] Laboratorio creado. Siguiente: sudo bash $DIR/servicios.sh iniciar"
}

borrar() {
  [ "${1:-}" = "quiet" ] || bash "$DIR/servicios.sh" detener quiet || true
  for n in "${NS[@]}"; do ip netns del "$n" 2>/dev/null || true; done
  rm -rf /etc/netns/auditor
  [ "${1:-}" = "quiet" ] || echo "[OK] Laboratorio borrado."
}

estado() {
  ip netns list | grep -E '^(sw|auditor|web|pc|imp|gw|bastion)\b' || echo "(laboratorio no creado)"
  ip netns exec auditor ping -c1 -W1 10.20.0.20 >/dev/null 2>&1 && echo "auditor -> web: OK" || echo "auditor -> web: sin respuesta"
}

case "${1:-}" in
  crear) crear ;; borrar) borrar ;; estado) estado ;;
  *) echo "Uso: sudo bash $0 crear|borrar|estado"; exit 1 ;;
esac
