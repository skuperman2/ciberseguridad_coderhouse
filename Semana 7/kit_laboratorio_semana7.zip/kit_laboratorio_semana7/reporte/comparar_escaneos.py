#!/usr/bin/env python3
"""Compara dos escaneos Nmap en XML y muestra qué cambió: equipos nuevos o desaparecidos y puertos abiertos/cerrados.

Uso: python3 comparar_escaneos.py escaneo_antes.xml escaneo_despues.xml

Es la base de la "gestión continua de exposición": escanear siempre igual y mirar solo las diferencias.
(Nmap trae una herramienta equivalente, ndiff, en un paquete aparte.)
"""
import sys
import xml.etree.ElementTree as ET


def leer(ruta):
    equipos = {}
    for h in ET.parse(ruta).getroot().findall("host"):
        if h.find("status").get("state") != "up":
            continue
        ip = next(a.get("addr") for a in h.findall("address") if a.get("addrtype").startswith("ipv"))
        pu = {}
        for p in h.findall("ports/port"):
            if p.find("state").get("state").startswith("open"):
                sv = p.find("service")
                pu[f"{p.get('portid')}/{p.get('protocol')}"] = (
                    " ".join(x for x in ((sv.get("product", ""), sv.get("version", "")) if sv is not None else ()) if x) or
                    (sv.get("name", "") if sv is not None else ""))
        equipos[ip] = pu
    return equipos


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    antes, despues = leer(sys.argv[1]), leer(sys.argv[2])
    cambios = 0
    for ip in sorted(set(despues) - set(antes)):
        print(f"[+] EQUIPO NUEVO: {ip}  puertos abiertos: {', '.join(despues[ip]) or 'ninguno'}"); cambios += 1
    for ip in sorted(set(antes) - set(despues)):
        print(f"[-] EQUIPO QUE YA NO RESPONDE: {ip}"); cambios += 1
    for ip in sorted(set(antes) & set(despues)):
        for pu in sorted(set(despues[ip]) - set(antes[ip])):
            print(f"[+] {ip}: puerto NUEVO abierto {pu} ({despues[ip][pu]})"); cambios += 1
        for pu in sorted(set(antes[ip]) - set(despues[ip])):
            print(f"[-] {ip}: puerto que se CERRÓ {pu}"); cambios += 1
        for pu in sorted(set(antes[ip]) & set(despues[ip])):
            if antes[ip][pu] != despues[ip][pu]:
                print(f"[~] {ip}: {pu} cambió de versión: «{antes[ip][pu]}» → «{despues[ip][pu]}»"); cambios += 1
    print("Sin cambios." if not cambios else f"{cambios} cambio(s).")


if __name__ == "__main__":
    main()
