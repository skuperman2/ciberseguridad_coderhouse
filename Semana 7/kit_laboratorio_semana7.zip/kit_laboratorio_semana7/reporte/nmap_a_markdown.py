#!/usr/bin/env python3
"""Convierte la salida XML de Nmap (-oX / -oA) en el ESQUELETO de un reporte de auditoría en Markdown.

Uso:
    python3 nmap_a_markdown.py escaneo.xml                    # todos los equipos "up"
    python3 nmap_a_markdown.py escaneo.xml --solo 10.20.0.20 10.20.0.30
    python3 nmap_a_markdown.py escaneo.xml --autor "Tu nombre" > reporte.md

Qué hace: arma, para cada equipo, la tabla de identificación (IP, MAC, nombre, S.O.) y la tabla de puertos
(puerto, estado, servicio, versión). Deja en blanco los tres campos del ANÁLISIS (qué es, por qué importa,
recomendación): eso lo escribís vos. Un reporte que sale de una herramienta sin interpretación es un "data dump".
"""
import argparse
import datetime
import sys
import xml.etree.ElementTree as ET


def texto_servicio(p):
    sv = p.find("service")
    if sv is None:
        return "", ""
    nombre = sv.get("name", "")
    if sv.get("tunnel") == "ssl":
        nombre = "ssl/" + nombre
    ver = " ".join(x for x in (sv.get("product", ""), sv.get("version", "")) if x)
    if sv.get("extrainfo"):
        ver += f" ({sv.get('extrainfo')})"
    return nombre, ver.strip()


def datos_equipo(h):
    d = {"ip": "", "mac": "", "fabricante": "", "nombre": "", "so": "", "puertos": [], "scripts": []}
    for a in h.findall("address"):
        if a.get("addrtype") in ("ipv4", "ipv6"):
            d["ip"] = a.get("addr")
        elif a.get("addrtype") == "mac":
            d["mac"], d["fabricante"] = a.get("addr"), a.get("vendor", "")
    hn = h.find("hostnames/hostname")
    if hn is not None:
        d["nombre"] = hn.get("name", "")
    om = h.find("os/osmatch")
    if om is not None:
        d["so"] = f"{om.get('name')} ({om.get('accuracy')} %)"
    else:
        # sin coincidencia de huella TCP/IP: usar lo que dedujo -sV (ostype), si existe
        tipos = sorted({sv.get("ostype") for sv in h.findall("ports/port/service") if sv.get("ostype")})
        d["so"] = ("No concluyente por -O; los servicios sugieren: " + ", ".join(tipos)) if tipos else "No determinado"
    for p in h.findall("ports/port"):
        st = p.find("state")
        nombre, ver = texto_servicio(p)
        d["puertos"].append((f"{p.get('portid')}/{p.get('protocol')}", st.get("state"), nombre, ver or "—"))
        for sc in p.findall("script"):
            d["scripts"].append((f"{p.get('portid')}/{p.get('protocol')}", sc.get("id"), (sc.get("output") or "").strip().splitlines()[0:2]))
    return d


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("xml")
    ap.add_argument("--solo", nargs="*", help="limitar a estas IP")
    ap.add_argument("--autor", default="_tu nombre_")
    ap.add_argument("--abiertos", action="store_true", help="mostrar solo puertos open")
    a = ap.parse_args()
    raiz = ET.parse(a.xml).getroot()
    equipos = []
    for h in raiz.findall("host"):
        st = h.find("status")
        if st is not None and st.get("state") != "up":
            continue
        d = datos_equipo(h)
        if a.solo and d["ip"] not in a.solo:
            continue
        equipos.append(d)
    out = []
    out.append("# Reporte de hallazgos de red — auditoría de red local\n")
    out.append(f"- **Fecha:** {datetime.date.today().isoformat()}")
    out.append(f"- **Autor/a:** {a.autor}")
    out.append(f"- **Comando(s) usado(s):** `{raiz.get('args', '')}`")
    out.append("- **Declaración de ética:** _Este escaneo se realizó únicamente sobre el laboratorio virtual del curso, "
               "con autorización del docente. No se escaneó ninguna red ajena._\n")
    for i, d in enumerate(equipos, 1):
        out.append(f"## Dispositivo {i}: {d['nombre'] or d['ip']}\n")
        out.append("### Identificación\n")
        out.append("| Dato | Valor |\n|---|---|")
        out.append(f"| Dirección IP | {d['ip']} |")
        out.append(f"| Dirección MAC | {d['mac'] or '— (equipo no local o no visible)'}{(' (' + d['fabricante'] + ')') if d['fabricante'] else ''} |")
        out.append(f"| Nombre (DNS inverso) | {d['nombre'] or '— (sin registro DNS)'} |")
        out.append(f"| Sistema operativo (-O) | {d['so']} |\n")
        out.append("### Puertos y servicios\n")
        out.append("| Puerto | Estado | Servicio | Versión detectada (-sV) |\n|---|---|---|---|")
        for pu, es, sv, ver in d["puertos"]:
            if a.abiertos and not es.startswith("open"):
                continue
            out.append(f"| {pu} | {es} | {sv} | {ver} |")
        if d["scripts"]:
            out.append("\n_Evidencia de scripts NSE (extracto):_")
            for pu, sid, lineas in d["scripts"]:
                out.append(f"- `{pu}` `{sid}`: {' '.join(l.strip() for l in lineas)}")
        out.append("\n### Análisis del hallazgo\n")
        out.append("- **¿Qué es?** _Descripción simple de lo observado (un servicio, una versión, un equipo)._")
        out.append("- **¿Por qué importa?** _Criterio: ¿debería estar abierto? ¿versión vigente? ¿a quién expone? "
                   "Citá la política (p. ej. «mínimo servicio necesario»). Evitá «creo que es peligroso»._")
        out.append("- **Recomendación:** _Acción concreta y verificable (cerrar/filtrar, actualizar, segmentar, restringir por origen)._\n")
    out.append("## Recomendaciones generales y límites\n")
    out.append("_Prioridades, qué no se pudo verificar (p. ej. -O no concluyente, banners que podrían no ser fieles) y próximos pasos._")
    print("\n".join(out))


if __name__ == "__main__":
    sys.exit(main())
